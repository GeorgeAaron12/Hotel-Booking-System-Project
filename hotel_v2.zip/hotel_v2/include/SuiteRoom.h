#pragma once
#include "Room.h"

class SuiteRoom : public Room {
private:
    int floorLevel;

public:
    SuiteRoom(const std::string& id, const std::string& name,
              const std::string& sr, const std::string& in,
              const std::string& out, int duration, int floor)
        : Room(id, name, sr, in, out, duration), floorLevel(floor) {}

    int getFloorLevel() const { return floorLevel; }
    std::string getType() const override { return "Suite"; }

    void displayDetails() const override {
        std::cout << "    [Suite Room]\n"
                  << "    ID:               " << roomId          << "\n"
                  << "    Number:           " << name            << "\n"
                  << "    Special Requests: " << specialRequests << "\n"
                  << "    Check In:         " << checkInDate     << "\n"
                  << "    Check Out:        " << checkOutDate    << "\n"
                  << "    Duration:         " << durationNights  << " night(s)\n"
                  << "    Floor:            " << floorLevel      << "\n";
    }

    void writeToFile(std::ofstream& ofs) const override {
        ofs << "Suite," << roomId << "," << name << "," << specialRequests << ","
            << checkInDate << "," << checkOutDate << ","
            << durationNights << "," << floorLevel << "\n";
    }
};
