#pragma once
#include "Room.h"

// ---------------------------------------------------------------
// SuiteRoom is the premium room type. It extends the base Room
// class with a floor level (which floor the suite is on).
//
// getType() returns "Suite" which is used in two places:
//   1. Booking::getNightlyRate() — suites cost more per night than
//      standard rooms (EUR 400 peak / EUR 250 off-peak vs
//      EUR 300 peak / EUR 150 off-peak for standard)
//   2. writeToFile() — so we know which class to recreate on load
//
// When saved to file the line looks like:
//   Suite,S201,Suite 201,Executive,01-06-2025,04-06-2025,3,5
//   (the last number is the floor level)
// ---------------------------------------------------------------

class SuiteRoom : public Room {
private:
    int floorLevel; // which floor the suite is on

public:
    SuiteRoom(const string& id, const string& name,
              const string& sr, const string& in,
              const string& out, int duration, int floor)
        : Room(id, name, sr, in, out, duration), floorLevel(floor) {}

    int getFloorLevel() const { return floorLevel; }
    string getType() const override { return "Suite"; }

    void displayDetails() const override {
        cout << "    [Suite Room]\n"
             << "    ID:               " << roomId          << "\n"
             << "    Number:           " << name            << "\n"
             << "    Special Requests: " << specialRequests << "\n"
             << "    Check In:         " << checkInDate     << "\n"
             << "    Check Out:        " << checkOutDate    << "\n"
             << "    Duration:         " << durationNights  << " night(s)\n"
             << "    Floor:            " << floorLevel      << "\n";
    }

    // Saves this suite's details to file so we can reload it later
    void writeToFile(ofstream& ofs) const override {
        ofs << "Suite," << roomId << "," << name << "," << specialRequests << ","
            << checkInDate << "," << checkOutDate << ","
            << durationNights << "," << floorLevel << "\n";
    }
};
