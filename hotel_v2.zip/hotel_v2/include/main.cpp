#include "Booking.h"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <fstream>
#include <algorithm>
#include <filesystem>

using namespace std;

// ---------------------------------------------------------------
// WHITE BOX TESTING — testing addItem() by covering every branch
//
// White box testing means we look at the actual source code and
// design tests that force every possible path through the function.
//
// addItem() has three distinct paths:
//   Path 1 (happy path) - room fits and isn't a duplicate → added OK
//   Path 2 (Branch 1)   - booking is already full → BookingFullException
//   Path 3 (Branch 2)   - same room name already exists → DuplicateRoomException
//
// We need at least one test per path to get full branch coverage:
//   Test 1 → covers Path 1
//   Test 2 → covers Path 2 (Branch 1)
//   Test 3 → covers Path 3 (Branch 2)
//   Test 4 → also tests sortItems(), sortItemsByDuration(), findItem()
//   Test 5 → tests saving a booking to file then loading it back
//
// Cyclomatic Complexity of addItem():
//   CC = number of independent paths through the function = 3
//   (one for each outcome: success, full, duplicate)
//   This tells us we need a minimum of 3 test cases — which we have.
// ---------------------------------------------------------------

void runTests() {
    cout << "\n========================================\n"
         << "  WHITE BOX TEST CASES\n"
         << "  Function under test: addItem()\n"
         << "========================================\n\n";

    // ---------------------------------------------------------------
    // TEST 1 — Path 1: normal add, everything works fine
    //
    // We create a booking with room for 2, then add 2 different rooms.
    // Neither branch in addItem() should fire — both rooms just get added.
    // Expected result: PASS, both rooms appear in the booking summary.
    // ---------------------------------------------------------------
    {
        cout << "-- Test 1: Normal add (capacity ok, no duplicate) --\n";
        auto* c = new MemberCustomer("Alice Smith", 3, 80.0, "Gold", 1);
        Booking b("Alice Smith", "Test Hotel", "01-06-2025", "03-06-2025", c, 2);
        auto* r1 = new StandardRoom("R101", "Room 101", "Seaside",   "01-06-2025", "03-06-2025", 2, "Double");
        auto* r2 = new SuiteRoom   ("S201", "Suite 201","Executive", "01-06-2025", "04-06-2025", 3, 5);
        try {
            b.addItem(r1); b.addItem(r2);
            b.displayDetails();
            cout << "  RESULT: PASS — both rooms added.\n\n";
        } catch (const exception& e) {
            // We don't expect any exception here, so if one fires the test fails
            cout << "  RESULT: FAIL — " << e.what() << "\n\n";
        }
    }

    // ---------------------------------------------------------------
    // TEST 2 — Path 2: Branch 1 — booking is full
    //
    // We create a booking with max 2 rooms, fill it up, then try to
    // add a third. addItem() should hit Branch 1 and throw
    // BookingFullException. We catch it and confirm the test passed.
    // Expected result: PASS, exception is thrown and caught cleanly.
    // ---------------------------------------------------------------
    {
        cout << "-- Test 2: Exceed max capacity --\n";
        auto* c = new GuestCustomer("Bob Jones", 2, 70.0, 0);
        Booking b("Bob Jones", "Test Hotel", "10-07-2025", "12-07-2025", c, 2);
        auto* r1 = new StandardRoom("R101", "Room 101", "Garden",   "10-07-2025", "11-07-2025", 1, "Single");
        auto* r2 = new StandardRoom("R102", "Room 102", "Poolside", "10-07-2025", "11-07-2025", 1, "Double");
        auto* r3 = new StandardRoom("R103", "Room 103", "Classic",  "10-07-2025", "11-07-2025", 1, "Twin");
        try {
            b.addItem(r1); b.addItem(r2); // fills the booking
            b.displayDetails();
            b.addItem(r3);               // this should throw BookingFullException
            cout << "  RESULT: FAIL — exception not thrown.\n\n";
            delete r3;
        } catch (const BookingFullException& e) {
            // This is the expected outcome — our custom exception was thrown correctly
            cout << "  [Exception caught] " << e.what() << "\n";
            cout << "  RESULT: PASS — third room correctly rejected.\n\n";
            delete r3;
        }
    }

    // ---------------------------------------------------------------
    // TEST 3 — Path 3: Branch 2 — duplicate room name
    //
    // We add "Suite 301" once successfully, then try to add another
    // room with the exact same name. find_if inside addItem() should
    // spot the duplicate and throw DuplicateRoomException.
    // Expected result: PASS, exception is thrown and caught cleanly.
    // ---------------------------------------------------------------
    {
        cout << "-- Test 3: Duplicate room name --\n";
        auto* c = new MemberCustomer("Carol White", 4, 120.0, "Platinum", 2);
        Booking b("Carol White", "Test Hotel", "15-08-2025", "19-08-2025", c, 5);
        auto* r1 = new SuiteRoom("S301", "Suite 301", "Penthouse", "15-08-2025", "19-08-2025", 4, 10);
        auto* r2 = new SuiteRoom("S301", "Suite 301", "Penthouse", "15-08-2025", "19-08-2025", 4, 10);
        try {
            b.addItem(r1);   // first add — should succeed
            b.displayDetails();
            b.addItem(r2);   // second add — should throw DuplicateRoomException
            cout << "  RESULT: FAIL — duplicate not caught.\n\n";
            delete r2;
        } catch (const DuplicateRoomException& e) {
            // This is the expected outcome — our custom exception was thrown correctly
            cout << "  [Exception caught] " << e.what() << "\n";
            cout << "  RESULT: PASS — duplicate correctly rejected.\n\n";
            delete r2;
        }
    }

    // ---------------------------------------------------------------
    // TEST 4 — STL sort (both criteria) and STL find
    //
    // We add 3 rooms in a random order, then:
    //   - sort alphabetically using sortItems()       [criterion 1]
    //   - sort by duration using sortItemsByDuration()[criterion 2]
    //   - search for a specific room using findItem() [find algorithm]
    //
    // This confirms the STL sort and find algorithms work correctly
    // on real data. Expected result: PASS, room is found after sorting.
    // ---------------------------------------------------------------
    {
        cout << "-- Test 4: STL sort and find --\n";
        auto* c = new MemberCustomer("David Lee", 2, 90.0, "Silver", 0);
        Booking b("David Lee", "Test Hotel", "01-09-2025", "03-09-2025", c, 5);

        // Add three rooms in non-alphabetical, non-duration order
        b.addItem(new StandardRoom("RZ", "Room Zebra", "Classic",  "01-09-2025", "04-09-2025", 3, "Twin"));
        b.addItem(new StandardRoom("RA", "Room Apple", "Seaside",  "01-09-2025", "02-09-2025", 1, "Single"));
        b.addItem(new SuiteRoom   ("RM", "Room Mango", "Tropical", "01-09-2025", "03-09-2025", 2, 4));

        cout << "  Before sort:\n";
        b.displayDetails();

        // Sort 1: alphabetical A-Z (Apple → Mango → Zebra)
        b.sortItems();
        cout << "  After alphabetical sort:\n";
        b.displayDetails();

        // Sort 2: shortest to longest stay (1 night → 2 nights → 3 nights)
        b.sortItemsByDuration();
        cout << "  After duration sort:\n";
        b.displayDetails();

        // Search for "Room Mango" using find_if inside findItem()
        Room* found = b.findItem("Room Mango");
        if (found) {
            cout << "  findItem(\"Room Mango\") — FOUND:\n";
            found->displayDetails();
            cout << "  RESULT: PASS — sort and find working.\n\n";
        } else {
            cout << "  RESULT: FAIL — findItem returned nullptr.\n\n";
        }
    }

    // ---------------------------------------------------------------
    // TEST 5 — File I/O: save a booking to file then reload it
    //
    // We create a booking with two rooms, save it to a text file,
    // then create a fresh empty booking and load the file into it.
    // If the reloaded booking shows the same details, the file I/O
    // is working correctly.
    // Expected result: PASS, reloaded booking matches the original.
    // ---------------------------------------------------------------
    {
        cout << "-- Test 5: File I/O (save and reload) --\n";
        auto* c = new MemberCustomer("Eve Brown", 3, 150.0, "Gold", 1);
        Booking b1("Eve Brown", "Grand Hotel", "01-11-2025", "04-11-2025", c, 5);
        b1.addItem(new SuiteRoom   ("SL",   "Suite Luxury", "Executive", "01-11-2025", "04-11-2025", 3, 8));
        b1.addItem(new StandardRoom("R205", "Room 205",     "Garden",    "01-11-2025", "03-11-2025", 2, "Double"));

        // Write the booking to a file
        filesystem::create_directories("data");
        b1.saveToFile("data/test_save.txt");

        // Create a blank booking and load the file into it
        auto* c2 = new GuestCustomer("Placeholder", 1, 1.0, 0);
        Booking b2("", "", "", "", c2, 10);
        b2.loadFromFile("data/test_save.txt");
        cout << "  Reloaded booking:\n";
        b2.displayDetails();
        cout << "  RESULT: PASS — data saved and reloaded correctly.\n\n";
    }

    cout << "========================================\n"
         << "  ALL TEST CASES COMPLETE\n"
         << "========================================\n\n";
}

// ---------------------------------------------------------------
// saveAllBookings() — saves every booking in the system to one file.
//
// The first line of the file is how many bookings there are, so
// loadAllBookings() knows when to stop reading. After that, each
// booking is written out one after another using saveToStream().
//
// If the file can't be opened we throw FileException (our custom
// error) rather than silently failing and losing all the data.
// ---------------------------------------------------------------
void saveAllBookings(const vector<Booking*>& bookings,
                     const string& filename = "data/bookings.txt") {
    filesystem::create_directories(
        filesystem::path(filename).parent_path());
    ofstream ofs(filename);
    if (!ofs.is_open()) throw FileException(filename);
    ofs << bookings.size() << "\n"; // write the count so the loader knows how many to expect
    for (const auto* b : bookings) b->saveToStream(ofs);
    cout << "  [OK] " << bookings.size() << " booking(s) saved to '" << filename << "'.\n";
}

// ---------------------------------------------------------------
// loadAllBookings() — reads all previously saved bookings from file.
//
// Called when the program starts so the employee can see and edit
// any bookings from the last session. If the file doesn't exist
// yet (first ever run) we just return an empty list and start fresh.
// ---------------------------------------------------------------
vector<Booking*> loadAllBookings(const string& filename = "data/bookings.txt") {
    vector<Booking*> result;
    ifstream ifs(filename);
    if (!ifs.is_open()) {
        cout << "  [Info] No saved data at '" << filename << "'. Starting fresh.\n";
        return result;
    }
    string line;
    getline(ifs, line); // first line is the number of bookings
    int count = 0;
    try { count = stoi(line); } catch (...) { return result; } // if the file is corrupt, bail out safely
    for (int i = 0; i < count; ++i) {
        Booking* b = Booking::loadFromStream(ifs);
        if (b) result.push_back(b);
    }
    cout << "  [OK] " << result.size() << " booking(s) loaded from '" << filename << "'.\n";
    return result;
}

// ---------------------------------------------------------------
// printMenu() — shows the main menu with the active booking info.
//
// Displays the employee's name at the top, a summary of whichever
// booking is currently selected, and the numbered list of options.
// ---------------------------------------------------------------
void printMenu(const vector<Booking*>& bookings, int activeIdx,
               const string& employeeName) {
    cout << "\n========= HOTEL BOOKING SYSTEM =========\n"
         << "  Employee: " << employeeName << "\n";
    if (activeIdx >= 0 && activeIdx < static_cast<int>(bookings.size())) {
        const Booking* b = bookings[activeIdx];
        cout << "  Active:   " << b->getName()
             << "  [" << b->getCheckIn() << " -> " << b->getCheckOut() << "]\n"
             << "  Rooms:    " << b->getRoomCount() << "/" << b->getMaxRooms()
             << "  Customer: " << b->getCustomer()->getName() << "\n";
    } else {
        cout << "  Active:   (none — create a booking first)\n";
    }
    cout << "  Total bookings: " << bookings.size() << "\n"
         << "-----------------------------------------\n"
         << "  1.  Display active booking details\n"
         << "  2.  Add a room to active booking\n"
         << "  3.  Remove a room from active booking\n"
         << "  4.  Search for a room\n"
         << "  5.  Sort bookings alphabetically by name\n"
         << "  6.  Sort bookings by check-in date\n"
         << "  7.  List bookings / switch active\n"
         << "  8.  Create new booking\n"
         << "  9.  Save all bookings\n"
         << "  10. Update customer / booking dates\n"
         << "  11. Run white box test cases\n"
         << "  0.  Exit\n"
         << "=========================================\n"
         << "  Choice: ";
}

// ---------------------------------------------------------------
// addRoomMenu() — walks the employee through adding a room.
//
// Asks for all the room details, builds the right room object
// (StandardRoom or SuiteRoom), then calls booking.addItem().
//
// If addItem() throws one of our custom exceptions (booking full
// or duplicate room), we catch it here and show a friendly message
// rather than letting the program crash.
// ---------------------------------------------------------------
void addRoomMenu(Booking& booking) {
    cout << "\n-- Add Room to: " << booking.getName() << " --\n";

    string checkIn, checkOut;
    cout << "  Check-in  (DD-MM-YYYY): "; getline(cin, checkIn);
    cout << "  Check-out (DD-MM-YYYY): "; getline(cin, checkOut);

    string rType;
    cout << "  Room type (Standard / Suite): "; cin >> rType;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    // Convert to lowercase so "Standard", "STANDARD", "standard" all work
    for (auto& ch : rType) ch = static_cast<char>(tolower(static_cast<unsigned char>(ch)));

    string rId, rName, rTheme;
    int dur;
    cout << "  Room ID:                "; getline(cin, rId);
    cout << "  Room number:            "; getline(cin, rName);
    cout << "  Special Requests:       "; getline(cin, rTheme);
    cout << "  Duration (nights):      "; cin >> dur;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    Room* room = nullptr;
    if (rType == "standard") {
        string bed;
        cout << "  Bed type (Single/Double/Twin): "; getline(cin, bed);
        room = new StandardRoom(rId, rName, rTheme, checkIn, checkOut, dur, bed);
    } else if (rType == "suite") {
        int floor;
        cout << "  Floor number:           "; cin >> floor;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        room = new SuiteRoom(rId, rName, rTheme, checkIn, checkOut, dur, floor);
    } else {
        cout << "  Unknown room type. Please enter 'Standard' or 'Suite'.\n";
        return;
    }

    double costPerNight;
    int extra;
    cout << "  Cost per night (EUR):   "; cin >> costPerNight;
    cout << "  Extra people in room:   "; cin >> extra;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    booking.getCustomer()->setNumNights(dur);
    booking.getCustomer()->setCostPerNight(costPerNight);
    booking.getCustomer()->setExtraPeople(extra);

    try {
        booking.addItem(room);
    } catch (const BookingFullException& e) {
        // Booking is full — tell the user and free the room we just created
        cout << "  [Error] " << e.what() << "\n"; delete room;
    } catch (const DuplicateRoomException& e) {
        // Same room name already exists — tell the user and free the room
        cout << "  [Error] " << e.what() << "\n"; delete room;
    }
}

// ---------------------------------------------------------------
// createBookingMenu() — lets the employee create a brand new booking.
//
// Asks for the hotel name, guest name, and customer type. Sets the
// maximum rooms to 10 (the default from the spec). Once created,
// the new booking becomes the active one automatically.
// ---------------------------------------------------------------
void createBookingMenu(vector<Booking*>& bookings, int& activeIdx) {
    cout << "\n-- Create New Booking --\n";

    string hotelName, guestName;
    cout << "  Hotel name:             "; getline(cin, hotelName);
    cout << "  Guest name:             "; getline(cin, guestName);

    string custType;
    cout << "  Customer type (Member / Guest): "; getline(cin, custType);

    Customer* c = nullptr;
    if (custType == "Member") {
        string tier;
        cout << "  Membership tier (Bronze/Silver/Gold/Platinum): ";
        getline(cin, tier);
        c = new MemberCustomer(guestName, 0, 0.0, tier, 0);
    } else {
        c = new GuestCustomer(guestName, 0, 0.0, 0);
    }

    // Max rooms is fixed at 10 — the spec says it can't be changed once set
    Booking* b = new Booking(guestName, hotelName, "", "", c, 10);
    bookings.push_back(b);
    activeIdx = static_cast<int>(bookings.size()) - 1;
    cout << "  [OK] Booking '" << hotelName << "' for guest '" << guestName << "' created.\n"
         << "  Use option 2 to add rooms with their check-in/out dates.\n";
}

// Lists every booking and lets the employee pick which one is active
void listAndSelectBooking(const vector<Booking*>& bookings, int& activeIdx) {
    cout << "\n-- All Bookings --\n";
    if (bookings.empty()) {
        cout << "  No bookings yet.\n";
        return;
    }
    for (int i = 0; i < static_cast<int>(bookings.size()); ++i) {
        const Booking* b = bookings[i];
        cout << "  [" << i + 1 << "] " << b->getName()
             << "  " << b->getCheckIn() << " -> " << b->getCheckOut()
             << "  Rooms: " << b->getRoomCount() << "/" << b->getMaxRooms()
             << "  Customer: " << b->getCustomer()->getName()
             << (i == activeIdx ? "  <-- active" : "") << "\n";
    }
    cout << "  Select booking number (0 to cancel): ";
    int sel;
    cin >> sel;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    if (sel >= 1 && sel <= static_cast<int>(bookings.size())) {
        activeIdx = sel - 1;
        cout << "  [OK] Active booking set to '" << bookings[activeIdx]->getName() << "'.\n";
    }
}

// Lets the employee update the customer details and dates for the active booking
void updateCustomerMenu(Booking& booking) {
    cout << "\n-- Update Customer / Booking Dates for: " << booking.getName() << " --\n";

    string checkIn, checkOut;
    cout << "  Check-in  (DD-MM-YYYY): "; getline(cin, checkIn);
    cout << "  Check-out (DD-MM-YYYY): "; getline(cin, checkOut);
    booking.setDates(checkIn, checkOut);

    string custName, custType;
    int nights, extra;
    double rate;
    cout << "  Customer name:                  "; getline(cin, custName);
    cout << "  Customer type (Member / Guest): "; getline(cin, custType);
    cout << "  Number of nights:               "; cin >> nights;
    cout << "  Cost per night (EUR):           "; cin >> rate;
    cout << "  Extra people in room:           "; cin >> extra;
    cin.ignore(numeric_limits<streamsize>::max(), '\n');

    Customer* c = nullptr;
    if (custType == "Member") {
        string tier;
        cout << "  Membership tier (Bronze/Silver/Gold/Platinum): ";
        getline(cin, tier);
        c = new MemberCustomer(custName, nights, rate, tier, extra);
    } else {
        c = new GuestCustomer(custName, nights, rate, extra);
    }

    booking.setCustomer(c);
    cout << "  [OK] Customer details updated.\n";
}

// ---------------------------------------------------------------
// main() — the entry point for the whole program.
//
// Flow:
//   1. Employee logs in with a name and password (3 attempts max)
//   2. Any previously saved bookings are loaded from file
//   3. The menu loop runs until the employee chooses to exit
//   4. All bookings are saved to file automatically on exit
//
// The try/catch block inside the menu loop handles every possible
// error that might come from menu operations. We catch our own
// custom exceptions first (most specific), then fall back to the
// standard library's built-in exception types:
//   - RoomNotFoundException  (our own — room not found during remove)
//   - FileException          (our own — file couldn't be opened)
//   - out_of_range           (built-in — bad index or number conversion)
//   - exception              (built-in base class — catches anything else)
//
// Catching from most specific to least specific is important — if
// we put exception first it would swallow all the others.
// ---------------------------------------------------------------
int main() {
    cout << "==========================================\n"
         << "  Welcome to Hotel Booking System!\n"
         << "  Please input your Employee Login below\n"
         << "==========================================\n\n";

    const string CORRECT_PASSWORD = "hotel123";
    const int MAX_ATTEMPTS = 3;
    string employeeName, password;
    cout << "  Employee name:  "; getline(cin, employeeName);

    // Give the employee three chances to enter the correct password
    bool loggedIn = false;
    for (int attempt = 1; attempt <= MAX_ATTEMPTS; ++attempt) {
        cout << "  Password:       "; cin >> password;
        if (password == CORRECT_PASSWORD) { loggedIn = true; break; }
        if (attempt < MAX_ATTEMPTS)
            cout << "  [Error] Incorrect password. "
                 << (MAX_ATTEMPTS - attempt) << " attempt(s) remaining.\n";
    }
    if (!loggedIn) {
        cout << "\n  [Access Denied] Too many failed attempts. Exiting.\n";
        return 1;
    }
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    cout << "\n  Welcome, " << employeeName << "!\n\n";

    // Load any bookings saved from the last session
    vector<Booking*> bookings = loadAllBookings();
    int activeIdx = bookings.empty() ? -1 : 0;

    int choice = -1;
    while (choice != 0) {
        printMenu(bookings, activeIdx, employeeName);

        if (!(cin >> choice)) {
            // If the user types something that isn't a number, clear the error and try again
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            continue;
        }
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

        // Options 1–4 and 10 only make sense if a booking exists
        bool needsActive = (choice >= 1 && choice <= 4) || choice == 10;
        if (needsActive && (activeIdx < 0 || activeIdx >= static_cast<int>(bookings.size()))) {
            cout << "  [Error] No active booking. Use option 8 to create one.\n";
            continue;
        }

        try {
            switch (choice) {
                case 1:
                    bookings[activeIdx]->displayDetails();
                    break;

                case 2:
                    // May throw BookingFullException or DuplicateRoomException —
                    // both are caught in addRoomMenu itself before reaching here
                    addRoomMenu(*bookings[activeIdx]);
                    break;

                case 3: {
                    // removeItem() will throw RoomNotFoundException if the name isn't found
                    string name;
                    cout << "  Room name to remove: ";
                    getline(cin, name);
                    bookings[activeIdx]->removeItem(name);
                    break;
                }

                case 4: {
                    // findItem() uses find_if internally — returns nullptr if not found
                    string name;
                    cout << "  Room name to search: ";
                    getline(cin, name);
                    Room* r = bookings[activeIdx]->findItem(name);
                    if (r) r->displayDetails();
                    else   cout << "  Room not found.\n";
                    break;
                }

                case 5:
                    // Sort all bookings A-Z by guest name using std::sort with a lambda
                    sort(bookings.begin(), bookings.end(),
                        [](const Booking* a, const Booking* b) {
                            return a->getName() < b->getName();
                        });
                    cout << "  [OK] Bookings sorted alphabetically by name.\n";
                    listAndSelectBooking(bookings, activeIdx);
                    break;

                case 6:
                    // Sort all bookings by check-in date (earliest first) using std::sort
                    sort(bookings.begin(), bookings.end(),
                        [](const Booking* a, const Booking* b) {
                            return a->getSortableCheckIn() < b->getSortableCheckIn();
                        });
                    cout << "  [OK] Bookings sorted by check-in date.\n";
                    listAndSelectBooking(bookings, activeIdx);
                    break;

                case 7:
                    listAndSelectBooking(bookings, activeIdx);
                    break;

                case 8:
                    createBookingMenu(bookings, activeIdx);
                    break;

                case 9:
                    // Write all bookings to file right now
                    saveAllBookings(bookings);
                    break;

                case 10:
                    updateCustomerMenu(*bookings[activeIdx]);
                    break;

                case 11:
                    // Run all 5 white box test cases
                    runTests();
                    break;

                case 0:
                    // Save everything before quitting
                    saveAllBookings(bookings);
                    cout << "  Goodbye!\n";
                    break;

                default:
                    cout << "  Invalid choice. Try again.\n";
            }
        } catch (const RoomNotFoundException& e) {
            // Our custom exception — the room the user tried to remove doesn't exist
            cout << "  [Error] " << e.what() << "\n";
        } catch (const FileException& e) {
            // Our custom exception — couldn't open the save/load file
            cout << "  [File Error] " << e.what() << "\n";
        } catch (const out_of_range& e) {
            // Built-in C++ exception — something went out of bounds (e.g. bad number)
            cout << "  [Range Error] " << e.what() << "\n";
        } catch (const exception& e) {
            // Built-in C++ base exception — catches anything we didn't specifically handle
            cout << "  [Unexpected Error] " << e.what() << "\n";
        }
    }

    // Free all the booking objects we allocated before the program closes
    for (auto* b : bookings) delete b;
    return 0;
}
