#include "Booking.h"
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <fstream>
#include <algorithm>
#include <filesystem>

// ================================================================
//  WHITE BOX TESTING — addItem() branch coverage
//
//  Branch 1: rooms.size() >= maxRooms  → BookingFullException
//  Branch 2: find_if finds duplicate   → DuplicateRoomException
//  Path 1 (neither) → happy path
//  Path 2 (branch 1) → capacity exceeded
//  Path 3 (branch 2) → duplicate rejected
//  Test 4: STL sort (alpha + duration) and find
//  Test 5: file I/O save and reload
// ================================================================

void runTests() {
    std::cout << "\n========================================\n"
              << "  WHITE BOX TEST CASES\n"
              << "  Function under test: addItem()\n"
              << "========================================\n\n";

    // TEST 1 — Path 1: normal add
    {
        std::cout << "-- Test 1: Normal add (capacity ok, no duplicate) --\n";
        auto* c = new MemberCustomer("Alice Smith", 3, 80.0, "Gold", 1);
        Booking b("Alice Smith", "Test Hotel", "01-06-2025", "03-06-2025", c, 2);
        auto* r1 = new StandardRoom("R101", "Room 101", "Seaside",   "01-06-2025", "03-06-2025", 2, "Double");
        auto* r2 = new SuiteRoom   ("S201", "Suite 201","Executive", "01-06-2025", "04-06-2025", 3, 5);
        try {
            b.addItem(r1); b.addItem(r2);
            b.displayDetails();
            std::cout << "  RESULT: PASS — both rooms added.\n\n";
        } catch (const std::exception& e) {
            std::cout << "  RESULT: FAIL — " << e.what() << "\n\n";
        }
    }

    // TEST 2 — Path 2: exceed capacity
    {
        std::cout << "-- Test 2: Exceed max capacity --\n";
        auto* c = new GuestCustomer("Bob Jones", 2, 70.0, 0);
        Booking b("Bob Jones", "Test Hotel", "10-07-2025", "12-07-2025", c, 2);
        auto* r1 = new StandardRoom("R101", "Room 101", "Garden",   "10-07-2025", "11-07-2025", 1, "Single");
        auto* r2 = new StandardRoom("R102", "Room 102", "Poolside", "10-07-2025", "11-07-2025", 1, "Double");
        auto* r3 = new StandardRoom("R103", "Room 103", "Classic",  "10-07-2025", "11-07-2025", 1, "Twin");
        try {
            b.addItem(r1); b.addItem(r2);
            b.displayDetails();
            b.addItem(r3);
            std::cout << "  RESULT: FAIL — exception not thrown.\n\n";
            delete r3;
        } catch (const BookingFullException& e) {
            std::cout << "  [Exception caught] " << e.what() << "\n";
            std::cout << "  RESULT: PASS — third room correctly rejected.\n\n";
            delete r3;
        }
    }

    // TEST 3 — Path 3: duplicate room name
    {
        std::cout << "-- Test 3: Duplicate room name --\n";
        auto* c = new MemberCustomer("Carol White", 4, 120.0, "Platinum", 2);
        Booking b("Carol White", "Test Hotel", "15-08-2025", "19-08-2025", c, 5);
        auto* r1 = new SuiteRoom("S301", "Suite 301", "Penthouse", "15-08-2025", "19-08-2025", 4, 10);
        auto* r2 = new SuiteRoom("S301", "Suite 301", "Penthouse", "15-08-2025", "19-08-2025", 4, 10);
        try {
            b.addItem(r1);
            b.displayDetails();
            b.addItem(r2);
            std::cout << "  RESULT: FAIL — duplicate not caught.\n\n";
            delete r2;
        } catch (const DuplicateRoomException& e) {
            std::cout << "  [Exception caught] " << e.what() << "\n";
            std::cout << "  RESULT: PASS — duplicate correctly rejected.\n\n";
            delete r2;
        }
    }

    // TEST 4 — STL sort and find
    {
        std::cout << "-- Test 4: STL sort and find --\n";
        auto* c = new MemberCustomer("David Lee", 2, 90.0, "Silver", 0);
        Booking b("David Lee", "Test Hotel", "01-09-2025", "03-09-2025", c, 5);
        b.addItem(new StandardRoom("RZ", "Room Zebra", "Classic",  "01-09-2025", "04-09-2025", 3, "Twin"));
        b.addItem(new StandardRoom("RA", "Room Apple", "Seaside",  "01-09-2025", "02-09-2025", 1, "Single"));
        b.addItem(new SuiteRoom   ("RM", "Room Mango", "Tropical", "01-09-2025", "03-09-2025", 2, 4));
        std::cout << "  Before sort:\n";        b.displayDetails();
        b.sortItems();
        std::cout << "  After alphabetical sort:\n"; b.displayDetails();
        b.sortItemsByDuration();
        std::cout << "  After duration sort:\n";     b.displayDetails();
        Room* found = b.findItem("Room Mango");
        if (found) {
            std::cout << "  findItem(\"Room Mango\") — FOUND:\n";
            found->displayDetails();
            std::cout << "  RESULT: PASS — sort and find working.\n\n";
        } else {
            std::cout << "  RESULT: FAIL — findItem returned nullptr.\n\n";
        }
    }

    // TEST 5 — File I/O
    {
        std::cout << "-- Test 5: File I/O (save and reload) --\n";
        auto* c = new MemberCustomer("Eve Brown", 3, 150.0, "Gold", 1);
        Booking b1("Eve Brown", "Grand Hotel", "01-11-2025", "04-11-2025", c, 5);
        b1.addItem(new SuiteRoom   ("SL",   "Suite Luxury", "Executive", "01-11-2025", "04-11-2025", 3, 8));
        b1.addItem(new StandardRoom("R205", "Room 205",     "Garden",    "01-11-2025", "03-11-2025", 2, "Double"));
        std::filesystem::create_directories("data");
        b1.saveToFile("data/test_save.txt");

        auto* c2 = new GuestCustomer("Placeholder", 1, 1.0, 0);
        Booking b2("", "", "", "", c2, 10);
        b2.loadFromFile("data/test_save.txt");
        std::cout << "  Reloaded booking:\n";
        b2.displayDetails();
        std::cout << "  RESULT: PASS — data saved and reloaded correctly.\n\n";
    }

    std::cout << "========================================\n"
              << "  ALL TEST CASES COMPLETE\n"
              << "========================================\n\n";
}

// ================================================================
//  MULTI-BOOKING FILE I/O
// ================================================================

void saveAllBookings(const std::vector<Booking*>& bookings,
                     const std::string& filename = "data/bookings.txt") {
    std::filesystem::create_directories(
        std::filesystem::path(filename).parent_path());
    std::ofstream ofs(filename);
    if (!ofs.is_open()) throw FileException(filename);
    ofs << bookings.size() << "\n";
    for (const auto* b : bookings) b->saveToStream(ofs);
    std::cout << "  [OK] " << bookings.size() << " booking(s) saved to '" << filename << "'.\n";
}

std::vector<Booking*> loadAllBookings(const std::string& filename = "data/bookings.txt") {
    std::vector<Booking*> result;
    std::ifstream ifs(filename);
    if (!ifs.is_open()) {
        std::cout << "  [Info] No saved data at '" << filename << "'. Starting fresh.\n";
        return result;
    }
    std::string line;
    std::getline(ifs, line);
    int count = 0;
    try { count = std::stoi(line); } catch (...) { return result; }
    for (int i = 0; i < count; ++i) {
        Booking* b = Booking::loadFromStream(ifs);
        if (b) result.push_back(b);
    }
    std::cout << "  [OK] " << result.size() << " booking(s) loaded from '" << filename << "'.\n";
    return result;
}

// ================================================================
//  MENU HELPERS
// ================================================================

void printMenu(const std::vector<Booking*>& bookings, int activeIdx,
               const std::string& employeeName) {
    std::cout << "\n========= HOTEL BOOKING SYSTEM =========\n"
              << "  Employee: " << employeeName << "\n";
    if (activeIdx >= 0 && activeIdx < static_cast<int>(bookings.size())) {
        const Booking* b = bookings[activeIdx];
        std::cout << "  Active:   " << b->getName()
                  << "  [" << b->getCheckIn() << " -> " << b->getCheckOut() << "]\n"
                  << "  Rooms:    " << b->getRoomCount() << "/" << b->getMaxRooms()
                  << "  Customer: " << b->getCustomer()->getName() << "\n";
    } else {
        std::cout << "  Active:   (none — create a booking first)\n";
    }
    std::cout << "  Total bookings: " << bookings.size() << "\n"
              << "-----------------------------------------\n"
              << "  1.  Display active booking details\n"
              << "  2.  Add a room to active booking\n"
              << "  3.  Remove a room from active booking\n"
              << "  4.  Search for a room\n"
              << "  5.  Sort bookings alphabetically by name\n"
              << "  6.  Sort bookings by check-in date\n"
              << "  7.  List bookings / switch active\n"
              << "  8.  Create new booking\n"
              << "  9.  Save all bookings\n"
              << "  10. Update customer / booking dates\n"
              << "  11. Run white box test cases\n"
              << "  0.  Exit\n"
              << "=========================================\n"
              << "  Choice: ";
}

void addRoomMenu(Booking& booking) {
    std::cout << "\n-- Add Room to: " << booking.getName() << " --\n";

    std::string checkIn, checkOut;
    std::cout << "  Check-in  (DD-MM-YYYY): "; std::getline(std::cin, checkIn);
    std::cout << "  Check-out (DD-MM-YYYY): "; std::getline(std::cin, checkOut);

    std::string rType;
    std::cout << "  Room type (Standard / Suite): "; std::cin >> rType;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    for (auto& ch : rType) ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));

    std::string rId, rName, rTheme;
    int dur;
    std::cout << "  Room ID:                "; std::getline(std::cin, rId);
    std::cout << "  Room number:            "; std::getline(std::cin, rName);
    std::cout << "  Special Requests:       "; std::getline(std::cin, rTheme);
    std::cout << "  Duration (nights):      "; std::cin >> dur;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    Room* room = nullptr;
    if (rType == "standard") {
        std::string bed;
        std::cout << "  Bed type (Single/Double/Twin): "; std::getline(std::cin, bed);
        room = new StandardRoom(rId, rName, rTheme, checkIn, checkOut, dur, bed);
    } else if (rType == "suite") {
        int floor;
        std::cout << "  Floor number:           "; std::cin >> floor;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        room = new SuiteRoom(rId, rName, rTheme, checkIn, checkOut, dur, floor);
    } else {
        std::cout << "  Unknown room type. Please enter 'Standard' or 'Suite'.\n";
        return;
    }

    double costPerNight;
    int extra;
    std::cout << "  Cost per night (EUR):   "; std::cin >> costPerNight;
    std::cout << "  Extra people in room:   "; std::cin >> extra;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    booking.getCustomer()->setNumNights(dur);
    booking.getCustomer()->setCostPerNight(costPerNight);
    booking.getCustomer()->setExtraPeople(extra);

    try {
        booking.addItem(room);
    } catch (const BookingFullException& e) {
        std::cout << "  [Error] " << e.what() << "\n"; delete room;
    } catch (const DuplicateRoomException& e) {
        std::cout << "  [Error] " << e.what() << "\n"; delete room;
    }
}

void createBookingMenu(std::vector<Booking*>& bookings, int& activeIdx) {
    std::cout << "\n-- Create New Booking --\n";

    std::string hotelName, guestName;
    std::cout << "  Hotel name:             "; std::getline(std::cin, hotelName);
    std::cout << "  Guest name:             "; std::getline(std::cin, guestName);

    std::string custType;
    std::cout << "  Customer type (Member / Guest): "; std::getline(std::cin, custType);

    Customer* c = nullptr;
    if (custType == "Member") {
        std::string tier;
        std::cout << "  Membership tier (Bronze/Silver/Gold/Platinum): ";
        std::getline(std::cin, tier);
        c = new MemberCustomer(guestName, 0, 0.0, tier, 0);
    } else {
        c = new GuestCustomer(guestName, 0, 0.0, 0);
    }

    Booking* b = new Booking(guestName, hotelName, "", "", c, 10);
    bookings.push_back(b);
    activeIdx = static_cast<int>(bookings.size()) - 1;
    std::cout << "  [OK] Booking '" << hotelName << "' for guest '" << guestName << "' created.\n"
              << "  Use option 2 to add rooms with their check-in/out dates.\n";
}

void listAndSelectBooking(const std::vector<Booking*>& bookings, int& activeIdx) {
    std::cout << "\n-- All Bookings --\n";
    if (bookings.empty()) {
        std::cout << "  No bookings yet.\n";
        return;
    }
    for (int i = 0; i < static_cast<int>(bookings.size()); ++i) {
        const Booking* b = bookings[i];
        std::cout << "  [" << i + 1 << "] " << b->getName()
                  << "  " << b->getCheckIn() << " -> " << b->getCheckOut()
                  << "  Rooms: " << b->getRoomCount() << "/" << b->getMaxRooms()
                  << "  Customer: " << b->getCustomer()->getName()
                  << (i == activeIdx ? "  <-- active" : "") << "\n";
    }
    std::cout << "  Select booking number (0 to cancel): ";
    int sel;
    std::cin >> sel;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (sel >= 1 && sel <= static_cast<int>(bookings.size())) {
        activeIdx = sel - 1;
        std::cout << "  [OK] Active booking set to '" << bookings[activeIdx]->getName() << "'.\n";
    }
}

void updateCustomerMenu(Booking& booking) {
    std::cout << "\n-- Update Customer / Booking Dates for: " << booking.getName() << " --\n";

    std::string checkIn, checkOut;
    std::cout << "  Check-in  (DD-MM-YYYY): "; std::getline(std::cin, checkIn);
    std::cout << "  Check-out (DD-MM-YYYY): "; std::getline(std::cin, checkOut);
    booking.setDates(checkIn, checkOut);

    std::string custName, custType;
    int nights, extra;
    double rate;
    std::cout << "  Customer name:                  "; std::getline(std::cin, custName);
    std::cout << "  Customer type (Member / Guest): "; std::getline(std::cin, custType);
    std::cout << "  Number of nights:               "; std::cin >> nights;
    std::cout << "  Cost per night (EUR):           "; std::cin >> rate;
    std::cout << "  Extra people in room:           "; std::cin >> extra;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    Customer* c = nullptr;
    if (custType == "Member") {
        std::string tier;
        std::cout << "  Membership tier (Bronze/Silver/Gold/Platinum): ";
        std::getline(std::cin, tier);
        c = new MemberCustomer(custName, nights, rate, tier, extra);
    } else {
        c = new GuestCustomer(custName, nights, rate, extra);
    }

    booking.setCustomer(c);
    std::cout << "  [OK] Customer details updated.\n";
}

// ================================================================
//  MAIN
// ================================================================
int main() {
    std::cout << "==========================================\n"
              << "  Welcome to Hotel Booking System!\n"
              << "  Please input your Employee Login below\n"
              << "==========================================\n\n";

    // Employee login
    const std::string CORRECT_PASSWORD = "hotel123";
    const int MAX_ATTEMPTS = 3;
    std::string employeeName, password;
    std::cout << "  Employee name:  "; std::getline(std::cin, employeeName);

    bool loggedIn = false;
    for (int attempt = 1; attempt <= MAX_ATTEMPTS; ++attempt) {
        std::cout << "  Password:       "; std::cin >> password;
        if (password == CORRECT_PASSWORD) { loggedIn = true; break; }
        if (attempt < MAX_ATTEMPTS)
            std::cout << "  [Error] Incorrect password. "
                      << (MAX_ATTEMPTS - attempt) << " attempt(s) remaining.\n";
    }
    if (!loggedIn) {
        std::cout << "\n  [Access Denied] Too many failed attempts. Exiting.\n";
        return 1;
    }
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    std::cout << "\n  Welcome, " << employeeName << "!\n\n";

    std::vector<Booking*> bookings = loadAllBookings();
    int activeIdx = bookings.empty() ? -1 : 0;

    int choice = -1;
    while (choice != 0) {
        printMenu(bookings, activeIdx, employeeName);

        if (!(std::cin >> choice)) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // Operations that need an active booking
        bool needsActive = (choice >= 1 && choice <= 4) || choice == 10;
        if (needsActive && (activeIdx < 0 || activeIdx >= static_cast<int>(bookings.size()))) {
            std::cout << "  [Error] No active booking. Use option 8 to create one.\n";
            continue;
        }

        try {
            switch (choice) {
                case 1: bookings[activeIdx]->displayDetails(); break;
                case 2: addRoomMenu(*bookings[activeIdx]); break;
                case 3: {
                    std::string name;
                    std::cout << "  Room name to remove: ";
                    std::getline(std::cin, name);
                    bookings[activeIdx]->removeItem(name);
                    break;
                }
                case 4: {
                    std::string name;
                    std::cout << "  Room name to search: ";
                    std::getline(std::cin, name);
                    Room* r = bookings[activeIdx]->findItem(name);
                    if (r) r->displayDetails();
                    else   std::cout << "  Room not found.\n";
                    break;
                }
                case 5:
                    std::sort(bookings.begin(), bookings.end(),
                        [](const Booking* a, const Booking* b) {
                            return a->getName() < b->getName();
                        });
                    std::cout << "  [OK] Bookings sorted alphabetically by name.\n";
                    listAndSelectBooking(bookings, activeIdx);
                    break;
                case 6:
                    std::sort(bookings.begin(), bookings.end(),
                        [](const Booking* a, const Booking* b) {
                            return a->getSortableCheckIn() < b->getSortableCheckIn();
                        });
                    std::cout << "  [OK] Bookings sorted by check-in date.\n";
                    listAndSelectBooking(bookings, activeIdx);
                    break;
                case 7: listAndSelectBooking(bookings, activeIdx); break;
                case 8: createBookingMenu(bookings, activeIdx); break;
                case 9: saveAllBookings(bookings); break;
                case 10: updateCustomerMenu(*bookings[activeIdx]); break;
                case 11: runTests(); break;
                case 0:
                    saveAllBookings(bookings);
                    std::cout << "  Goodbye!\n";
                    break;
                default:
                    std::cout << "  Invalid choice. Try again.\n";
            }
        } catch (const RoomNotFoundException& e) {
            std::cout << "  [Error] " << e.what() << "\n";
        } catch (const FileException& e) {
            std::cout << "  [File Error] " << e.what() << "\n";
        } catch (const std::out_of_range& e) {
            std::cout << "  [Range Error] " << e.what() << "\n";
        } catch (const std::exception& e) {
            std::cout << "  [Unexpected Error] " << e.what() << "\n";
        }
    }

    for (auto* b : bookings) delete b;
    return 0;
}
