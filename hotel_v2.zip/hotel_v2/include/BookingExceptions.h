#pragma once
#include <stdexcept>
#include <string>

// Thrown when trying to add a room to a booking that is already full
class BookingFullException : public std::runtime_error {
public:
    explicit BookingFullException(int max)
        : std::runtime_error("Booking is full — maximum of " +
                             std::to_string(max) + " rooms reached.") {}
};

// Thrown when trying to add a room that already exists in the booking
class DuplicateRoomException : public std::runtime_error {
public:
    explicit DuplicateRoomException(const std::string& name)
        : std::runtime_error("Room '" + name + "' is already in this booking.") {}
};

// Thrown when trying to remove a room that does not exist
class RoomNotFoundException : public std::runtime_error {
public:
    explicit RoomNotFoundException(const std::string& name)
        : std::runtime_error("Room '" + name + "' was not found in this booking.") {}
};

// Thrown when a file cannot be opened for reading or writing
class FileException : public std::runtime_error {
public:
    explicit FileException(const std::string& filename)
        : std::runtime_error("Could not open file: " + filename) {}
};
