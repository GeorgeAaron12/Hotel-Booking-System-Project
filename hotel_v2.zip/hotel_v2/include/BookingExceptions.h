#pragma once
#include <stdexcept>
#include <string>

using namespace std;

// ---------------------------------------------------------------
// This file contains all our custom error types (exceptions).
//
// In C++ you can create your own exception classes by inheriting
// from built-in ones like runtime_error. That way, when something
// goes wrong we can throw a specific, named error instead of just
// crashing or printing a vague message.
//
// We have four custom exceptions here, one for each thing that
// can go wrong inside a booking:
//   - Trying to add too many rooms
//   - Adding the same room twice
//   - Trying to remove a room that doesn't exist
//   - Not being able to open a file
//
// These are all caught in main.cpp and in addRoomMenu() so the
// user sees a friendly error message instead of the program dying.
// ---------------------------------------------------------------

// Thrown when someone tries to add a room but the booking is already full
class BookingFullException : public runtime_error {
public:
    explicit BookingFullException(int max)
        : runtime_error("Booking is full — maximum of " +
                             to_string(max) + " rooms reached.") {}
};

// Thrown when someone tries to add a room that is already in the booking
class DuplicateRoomException : public runtime_error {
public:
    explicit DuplicateRoomException(const string& name)
        : runtime_error("Room '" + name + "' is already in this booking.") {}
};

// Thrown when someone tries to remove a room that can't be found
class RoomNotFoundException : public runtime_error {
public:
    explicit RoomNotFoundException(const string& name)
        : runtime_error("Room '" + name + "' was not found in this booking.") {}
};

// Thrown when we try to open a file for saving or loading but it fails
class FileException : public runtime_error {
public:
    explicit FileException(const string& filename)
        : runtime_error("Could not open file: " + filename) {}
};
