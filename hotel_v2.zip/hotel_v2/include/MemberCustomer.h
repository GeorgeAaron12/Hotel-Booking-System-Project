#pragma once
#include "Customer.h"

class MemberCustomer : public Customer {
private:
    std::string memberTier;
    double baseCostPerNight;

public:
    MemberCustomer(const std::string& name, int nights,
                   double costPerNight, const std::string& tier, int extraPeople)
        : Customer(name, nights, 0.0, extraPeople),
          memberTier(tier), baseCostPerNight(costPerNight)
    {
        double full = costPerNight * nights;
        totalCost = full * (1.0 - getDiscount());
    }

    std::string getMemberTier() const { return memberTier; }

    double getDiscount() const override {
        if (memberTier == "Platinum") return 0.20;
        if (memberTier == "Gold")     return 0.10;
        if (memberTier == "Silver")   return 0.05;
        if (memberTier == "Bronze")   return 0.025;
        return 0.0;
    }

    std::string getType() const override { return "Member"; }

    void displayDetails() const override {
        std::cout << "    [Member Customer]\n"
                  << "    Name:          " << name              << "\n"
                  << "    Nights:        " << numNights         << "\n"
                  << "    Tier:          " << memberTier        << "\n"
                  << "    Discount:      " << getDiscount() * 100 << "%\n"
                  << "    Extra People:  " << numExtraPeople    << "\n"
                  << "    Total Cost:    EUR " << totalCost     << "\n";
    }

    void writeToFile(std::ofstream& ofs) const override {
        ofs << "Member," << name << "," << numNights << ","
            << baseCostPerNight << "," << memberTier << ","
            << numExtraPeople << "\n";
    }
};
