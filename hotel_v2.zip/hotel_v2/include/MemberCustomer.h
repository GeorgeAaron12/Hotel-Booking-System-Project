#pragma once
#include "Customer.h"

// ---------------------------------------------------------------
// MemberCustomer represents a loyalty-member guest who gets a
// discount based on their membership tier:
//   Bronze   →  2.5% off
//   Silver   →  5%   off
//   Gold     → 10%   off
//   Platinum → 20%   off
//
// The discount is applied in the constructor so totalCost already
// reflects the reduced price. Booking::displayDetails() also uses
// getDiscount() to show the discount line in the booking summary.
//
// When saved to file the line looks like:
//   Member,Alice Smith,3,120.0,Gold,1
//   (type, name, nights, cost per night, tier, extra people)
// ---------------------------------------------------------------

class MemberCustomer : public Customer {
private:
    string memberTier;       // "Bronze" | "Silver" | "Gold" | "Platinum"
    double baseCostPerNight; // kept separately so we can write the correct value to file

public:
    MemberCustomer(const string& name, int nights,
                   double costPerNight, const string& tier, int extraPeople)
        : Customer(name, nights, 0.0, extraPeople),
          memberTier(tier), baseCostPerNight(costPerNight)
    {
        // Work out the full price first, then apply the member discount
        double full = costPerNight * nights;
        totalCost = full * (1.0 - getDiscount());
    }

    string getMemberTier() const { return memberTier; }

    // Returns how much discount this member gets (e.g. Gold = 0.10 = 10%)
    double getDiscount() const override {
        if (memberTier == "Platinum") return 0.20;
        if (memberTier == "Gold")     return 0.10;
        if (memberTier == "Silver")   return 0.05;
        if (memberTier == "Bronze")   return 0.025;
        return 0.0;
    }

    string getType() const override { return "Member"; }

    void displayDetails() const override {
        cout << "    [Member Customer]\n"
             << "    Name:          " << name              << "\n"
             << "    Nights:        " << numNights         << "\n"
             << "    Tier:          " << memberTier        << "\n"
             << "    Discount:      " << getDiscount() * 100 << "%\n"
             << "    Extra People:  " << numExtraPeople    << "\n"
             << "    Total Cost:    EUR " << totalCost     << "\n";
    }

    // Saves this member's details to file so they can be loaded next time
    void writeToFile(ofstream& ofs) const override {
        ofs << "Member," << name << "," << numNights << ","
            << baseCostPerNight << "," << memberTier << ","
            << numExtraPeople << "\n";
    }
};
