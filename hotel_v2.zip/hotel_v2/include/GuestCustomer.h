#pragma once
#include "Customer.h"

// ---------------------------------------------------------------
// GuestCustomer represents a regular hotel guest with no loyalty
// membership. They pay the full price — getDiscount() always
// returns 0.0, so no discount is applied when calculating the
// total in Booking::displayDetails().
//
// When saved to file the line looks like:
//   Guest,John Smith,3,120.0,0
//   (type, name, nights, cost per night, extra people)
// ---------------------------------------------------------------

class GuestCustomer : public Customer {
private:
    double baseCostPerNight; // kept separately so we can write the correct value to file

public:
    GuestCustomer(const string& name, int nights,
                  double costPerNight, int extraPeople)
        : Customer(name, nights, costPerNight * nights, extraPeople),
          baseCostPerNight(costPerNight) {}

    // No discount for regular guests
    double getDiscount() const override { return 0.0; }

    string getType() const override { return "Guest"; }

    void displayDetails() const override {
        cout << "    [Guest Customer]\n"
             << "    Name:         " << name           << "\n"
             << "    Nights:       " << numNights      << "\n"
             << "    Extra People: " << numExtraPeople << "\n"
             << "    Total Cost:   EUR " << totalCost  << "\n";
    }

    // Saves this guest's details to file so they can be loaded next time
    void writeToFile(ofstream& ofs) const override {
        ofs << "Guest," << name << "," << numNights << ","
            << baseCostPerNight << "," << numExtraPeople << "\n";
    }
};
