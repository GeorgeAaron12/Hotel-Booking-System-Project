#pragma once
#include "Customer.h"

class GuestCustomer : public Customer {
private:
    double baseCostPerNight;

public:
    GuestCustomer(const std::string& name, int nights,
                  double costPerNight, int extraPeople)
        : Customer(name, nights, costPerNight * nights, extraPeople),
          baseCostPerNight(costPerNight) {}

    double getDiscount() const override { return 0.0; }
    std::string getType() const override { return "Guest"; }

    void displayDetails() const override {
        std::cout << "    [Guest Customer]\n"
                  << "    Name:         " << name           << "\n"
                  << "    Nights:       " << numNights      << "\n"
                  << "    Extra People: " << numExtraPeople << "\n"
                  << "    Total Cost:   EUR " << totalCost  << "\n";
    }

    void writeToFile(std::ofstream& ofs) const override {
        ofs << "Guest," << name << "," << numNights << ","
            << baseCostPerNight << "," << numExtraPeople << "\n";
    }
};
