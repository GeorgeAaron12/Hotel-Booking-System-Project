#pragma once
#include <string>
#include <iostream>
#include <fstream>

// Customer is the abstract base class for all guest types.
// According to the spec, every customer has:
//   - a name
//   - number of nights staying
//   - the total cost of their stay
// Subclasses add membership tier discounts and extra-person tracking.
class Customer {
protected:
    std::string name;
    int numNights;
    double totalCost;
    int numExtraPeople;

public:
    Customer(const std::string& n, int nights, double cost, int extra = 0)
        : name(n), numNights(nights), totalCost(cost), numExtraPeople(extra) {}

    virtual ~Customer() = default;

    std::string getName()         const { return name; }
    int getNumNights()            const { return numNights; }
    double getTotalCost()         const { return totalCost; }
    int getNumExtraPeople()       const { return numExtraPeople; }
    void setNumNights(int n)            { numNights = n; }
    void setCostPerNight(double c)      { totalCost = c; }
    void setExtraPeople(int n)          { numExtraPeople = n; }

    // Returns the discount fraction for this customer type (0.0 to 1.0)
    virtual double getDiscount() const = 0;
    virtual void displayDetails() const = 0;
    virtual void writeToFile(std::ofstream& ofs) const = 0;
    virtual std::string getType() const = 0;

    bool operator==(const Customer& other) const {
        return name == other.name;
    }
};
