#pragma once
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// ---------------------------------------------------------------
// Customer is the base class for all the guests in the system.
// It stores the core details every customer has: their name, how
// many nights they're staying, the total cost, and how many extra
// people are in the room with them.
//
// Like Room, this is abstract — you can't create a plain Customer.
// You have to use either GuestCustomer or MemberCustomer:
//   - GuestCustomer  → no discount, pays full price
//   - MemberCustomer → gets a discount based on their loyalty tier
//
// getDiscount() is the key method that differs between the two.
// It returns a number between 0.0 and 1.0 (e.g. 0.10 = 10% off).
// Booking::displayDetails() uses it to calculate the final price.
// ---------------------------------------------------------------

class Customer {
protected:
    string name;         // the guest's full name
    int numNights;       // how many nights they're staying
    double totalCost;    // the total cost of their stay in EUR
    int numExtraPeople;  // how many extra people are sharing the room

public:
    Customer(const string& n, int nights, double cost, int extra = 0)
        : name(n), numNights(nights), totalCost(cost), numExtraPeople(extra) {}

    virtual ~Customer() = default;

    string getName()         const { return name; }
    int getNumNights()       const { return numNights; }
    double getTotalCost()    const { return totalCost; }
    int getNumExtraPeople()  const { return numExtraPeople; }
    void setNumNights(int n)       { numNights = n; }
    void setCostPerNight(double c) { totalCost = c; }
    void setExtraPeople(int n)     { numExtraPeople = n; }

    // Returns the discount for this customer (0.0 for guests, up to 0.20 for members)
    virtual double getDiscount() const = 0;

    virtual void displayDetails() const = 0;

    // Saves this customer's details to a file so we can reload them later
    virtual void writeToFile(ofstream& ofs) const = 0;

    virtual string getType() const = 0;

    bool operator==(const Customer& other) const {
        return name == other.name;
    }
};
