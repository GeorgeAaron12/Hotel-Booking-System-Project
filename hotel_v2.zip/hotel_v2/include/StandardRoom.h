#pragma once
#include "Room.h"

// ---------------------------------------------------------------
// StandardRoom is one of the two concrete room types (the other
// is SuiteRoom). It adds a bed type on top of the base Room data
// (Single, Double, or Twin).
//
// getType() returns "Standard" which is used in two places:
//   1. Booking::getNightlyRate() — to pick the correct room price
//   2. writeToFile() — so we know which class to recreate on load
//
// When saved to file the line looks like:
//   Standard,R101,Room 101,Seaside,01-06-2025,03-06-2025,2,Double
// ---------------------------------------------------------------

class StandardRoom : public Room {
private:
    string bedType; // "Single", "Double", or "Twin"

public:
    StandardRoom(const string& id, const string& name,
                 const string& sr, const string& in,
                 const string& out, int duration, const string& bed)
        : Room(id, name, sr, in, out, duration), bedType(bed) {}

    string getBedType() const { return bedType; }
    string getType() const override { return "Standard"; }

    void displayDetails() const override {
        cout << "    [Standard Room]\n"
             << "    ID:               " << roomId          << "\n"
             << "    Number:           " << name            << "\n"
             << "    Special Requests: " << specialRequests << "\n"
             << "    Check In:         " << checkInDate     << "\n"
             << "    Check Out:        " << checkOutDate    << "\n"
             << "    Duration:         " << durationNights  << " night(s)\n"
             << "    Bed Type:         " << bedType         << "\n";
    }

    // Saves this room's details to file so we can reload it later
    void writeToFile(ofstream& ofs) const override {
        ofs << "Standard," << roomId << "," << name << "," << specialRequests << ","
            << checkInDate << "," << checkOutDate << ","
            << durationNights << "," << bedType << "\n";
    }
};
