#pragma once
#include "Room.h"

class StandardRoom : public Room {
private:
    std::string bedType;

public:
    StandardRoom(const std::string& id, const std::string& name,
                 const std::string& sr, const std::string& in,
                 const std::string& out, int duration, const std::string& bed)
        : Room(id, name, sr, in, out, duration), bedType(bed) {}

    std::string getBedType() const { return bedType; }
    std::string getType() const override { return "Standard"; }

    void displayDetails() const override {
        std::cout << "    [Standard Room]\n"
                  << "    ID:               " << roomId          << "\n"
                  << "    Number:           " << name            << "\n"
                  << "    Special Requests: " << specialRequests << "\n"
                  << "    Check In:         " << checkInDate     << "\n"
                  << "    Check Out:        " << checkOutDate    << "\n"
                  << "    Duration:         " << durationNights  << " night(s)\n"
                  << "    Bed Type:         " << bedType         << "\n";
    }

    void writeToFile(std::ofstream& ofs) const override {
        ofs << "Standard," << roomId << "," << name << "," << specialRequests << ","
            << checkInDate << "," << checkOutDate << ","
            << durationNights << "," << bedType << "\n";
    }
};
