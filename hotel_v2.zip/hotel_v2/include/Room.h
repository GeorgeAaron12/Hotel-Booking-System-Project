#pragma once
#include <string>
#include <iostream>
#include <fstream>

class Room {
protected:
    std::string roomId;
    std::string name;
    std::string specialRequests;
    std::string checkInDate;
    std::string checkOutDate;
    int durationNights;

public:
    Room(const std::string& id, const std::string& n, const std::string& sr,
         const std::string& in, const std::string& out, int dur)
        : roomId(id), name(n), specialRequests(sr),
          checkInDate(in), checkOutDate(out), durationNights(dur) {}

    virtual ~Room() = default;

    std::string getId()              const { return roomId; }
    std::string getName()            const { return name; }
    std::string getSpecialRequests() const { return specialRequests; }
    std::string getCheckIn()         const { return checkInDate; }
    std::string getCheckOut()        const { return checkOutDate; }
    int getDuration()                const { return durationNights; }

    virtual void displayDetails() const = 0;
    virtual void writeToFile(std::ofstream& ofs) const = 0;
    virtual std::string getType() const = 0;

    bool operator==(const Room& other) const { return name == other.name; }
};
