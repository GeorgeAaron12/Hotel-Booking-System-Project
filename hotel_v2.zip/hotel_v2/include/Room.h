#pragma once
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

// ---------------------------------------------------------------
// Room is the base class for every type of room in the system.
// It holds all the details that every room has in common, like
// its ID, name, check-in/out dates, and how many nights it's
// booked for.
//
// It's abstract, meaning you can't create a plain Room directly.
// Instead, you must create a StandardRoom or SuiteRoom — both of
// those inherit from this class and add their own extra details.
//
// The operator== at the bottom compares two rooms by name. This
// is used by find_if in Booking.h to check whether a room with
// the same name has already been added (to prevent duplicates).
// ---------------------------------------------------------------

class Room {
protected:
    string roomId;          // the unique ID for this room, e.g. "R101"
    string name;            // the room's display name, e.g. "Room 101"
    string specialRequests; // any theme or special requests for the room
    string checkInDate;     // when the guest checks in (DD-MM-YYYY)
    string checkOutDate;    // when the guest checks out (DD-MM-YYYY)
    int durationNights;     // how many nights the room is booked for

public:
    Room(const string& id, const string& n, const string& sr,
         const string& in, const string& out, int dur)
        : roomId(id), name(n), specialRequests(sr),
          checkInDate(in), checkOutDate(out), durationNights(dur) {}

    virtual ~Room() = default;

    string getId()              const { return roomId; }
    string getName()            const { return name; }
    string getSpecialRequests() const { return specialRequests; }
    string getCheckIn()         const { return checkInDate; }
    string getCheckOut()        const { return checkOutDate; }
    int getDuration()           const { return durationNights; }

    // These three must be implemented by every subclass
    virtual void displayDetails() const = 0;
    virtual void writeToFile(ofstream& ofs) const = 0;
    virtual string getType() const = 0;

    // Lets us compare two rooms — returns true if they have the same name.
    // find_if uses this in Booking::addItem() to spot duplicates.
    bool operator==(const Room& other) const { return name == other.name; }
};
