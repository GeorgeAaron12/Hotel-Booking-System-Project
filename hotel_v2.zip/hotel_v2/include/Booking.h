#pragma once
#include "Room.h"
#include "Customer.h"
#include "StandardRoom.h"
#include "SuiteRoom.h"
#include "MemberCustomer.h"
#include "GuestCustomer.h"
#include "BookingExceptions.h"
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>

class Booking {
private:
    std::string bookingName;  // customer name — used as identifier in lists
    std::string hotelName;    // hotel name — shown in summary display
    int maxRooms;
    std::string checkInDate;
    std::string checkOutDate;
    std::vector<Room*> rooms;
    Customer* customer;

    static std::string toSortable(const std::string& date) {
        if (date.size() < 10) return date;
        return date.substr(6, 4) + "-" + date.substr(3, 2) + "-" + date.substr(0, 2);
    }

    static void trimCR(std::string& s) {
        if (!s.empty() && s.back() == '\r') s.pop_back();
    }

    static double getNightlyRate(const std::string& roomType, const std::string& checkIn) {
        int month = 0;
        if (checkIn.size() >= 5) {
            try { month = std::stoi(checkIn.substr(3, 2)); }
            catch (...) {}
        }
        bool peak = (month >= 5 && month <= 8);
        if (roomType == "Suite")
            return peak ? 400.0 : 250.0;
        return peak ? 300.0 : 150.0;
    }

public:
    Booking(const std::string& name, const std::string& hotel,
            const std::string& in, const std::string& out,
            Customer* c, int max = 10)
        : bookingName(name), hotelName(hotel), maxRooms(max),
          checkInDate(in), checkOutDate(out), customer(c) {}

    ~Booking() {
        for (auto r : rooms) delete r;
        delete customer;
    }

    std::string getName()        const { return bookingName; }
    std::string getHotelName()   const { return hotelName; }
    int getMaxRooms()            const { return maxRooms; }
    int getRoomCount()           const { return static_cast<int>(rooms.size()); }
    std::string getCheckIn()     const { return checkInDate; }
    std::string getCheckOut()    const { return checkOutDate; }
    std::string getSortableCheckIn() const { return toSortable(checkInDate); }
    Customer* getCustomer()      const { return customer; }

    void setCustomer(Customer* c) {
        delete customer;
        customer = c;
    }

    void setDates(const std::string& in, const std::string& out) {
        checkInDate  = in;
        checkOutDate = out;
    }

    void addItem(Room* r) {
        if (static_cast<int>(rooms.size()) >= maxRooms)
            throw BookingFullException(maxRooms);
        auto it = std::find_if(rooms.begin(), rooms.end(),
            [&r](const Room* existing) { return *existing == *r; });
        if (it != rooms.end())
            throw DuplicateRoomException(r->getName());
        rooms.push_back(r);
        std::cout << "  [OK] Room '" << r->getName() << "' added to booking.\n";
    }

    void removeItem(const std::string& roomName) {
        auto it = std::find_if(rooms.begin(), rooms.end(),
            [&roomName](const Room* r) { return r->getName() == roomName; });
        if (it == rooms.end())
            throw RoomNotFoundException(roomName);
        delete *it;
        rooms.erase(it);
        std::cout << "  [OK] Room '" << roomName << "' removed.\n";
    }

    Room* findItem(const std::string& roomName) const {
        auto it = std::find_if(rooms.begin(), rooms.end(),
            [&roomName](const Room* r) { return r->getName() == roomName; });
        return (it != rooms.end()) ? *it : nullptr;
    }

    void sortItems() {
        std::sort(rooms.begin(), rooms.end(),
            [](const Room* a, const Room* b) { return a->getName() < b->getName(); });
        std::cout << "  [OK] Rooms sorted alphabetically by name.\n";
    }

    void sortItemsByDuration() {
        std::sort(rooms.begin(), rooms.end(),
            [](const Room* a, const Room* b) { return a->getDuration() < b->getDuration(); });
        std::cout << "  [OK] Rooms sorted by duration (shortest first).\n";
    }

    void displayDetails() const {
        std::cout << "\n========================================\n"
                  << "  BOOKING SUMMARY\n"
                  << "========================================\n"
                  << "  Hotel:       " << hotelName    << "\n"
                  << "  Customer:    " << bookingName  << "\n"
                  << "  Rooms:       " << rooms.size() << "/" << maxRooms << "\n"
                  << "----------------------------------------\n";

        if (rooms.empty()) {
            std::cout << "  No rooms added yet.\n";
        } else {
            double baseTotal = 0.0;
            int roomNum = 1;
            for (const auto& r : rooms) {
                double rate      = getNightlyRate(r->getType(), r->getCheckIn());
                double roomTotal = r->getDuration() * rate;
                baseTotal += roomTotal;
                std::cout << "  Room " << roomNum++ << ":\n"
                          << "    ID:           " << r->getId()             << "\n"
                          << "    Number:       " << r->getName()           << "\n"
                          << "    Type:         " << r->getType()           << "\n"
                          << "    Special Req:  " << r->getSpecialRequests()<< "\n"
                          << "    Check In:     " << r->getCheckIn()        << "\n"
                          << "    Check Out:    " << r->getCheckOut()       << "\n"
                          << "    Duration:     " << r->getDuration()       << " night(s)\n"
                          << "    Rate/Night:   EUR " << rate               << "\n"
                          << "    Room Total:   EUR " << roomTotal          << "\n"
                          << "  ..............................\n";
            }

            double discount   = customer->getDiscount();
            double finalTotal = baseTotal * (1.0 - discount);

            std::cout << "  Subtotal:      EUR " << baseTotal << "\n";
            if (discount > 0.0) {
                std::cout << "  Discount:      " << discount * 100 << "% ("
                          << customer->getType() << ")\n"
                          << "  Total:         EUR " << finalTotal << "\n";
            } else {
                std::cout << "  Total:         EUR " << finalTotal << "\n";
            }
        }
        std::cout << "========================================\n";
    }

    // ── saveToStream ─────────────────────────────────────────────
    // Writes one booking block to an already-open output stream.
    void saveToStream(std::ofstream& ofs) const {
        ofs << bookingName  << "\n"
            << hotelName    << "\n"
            << maxRooms     << "\n"
            << checkInDate  << "\n"
            << checkOutDate << "\n";
        customer->writeToFile(ofs);
        ofs << "ROOMS\n";
        for (const auto& r : rooms) r->writeToFile(ofs);
        ofs << "END\n";
    }

    // ── loadFromStream ────────────────────────────────────────────
    // Static factory — reads one booking block from an open stream.
    // Returns a heap-allocated Booking* or nullptr on failure.
    static Booking* loadFromStream(std::ifstream& ifs) {
        auto trim = [](std::string& s) {
            if (!s.empty() && s.back() == '\r') s.pop_back();
        };

        std::string line;
        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        std::string bName = line;

        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        std::string hName = line;

        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        int maxR = std::stoi(line);

        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        std::string inDate = line;

        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        std::string outDate = line;

        // Customer line
        if (!std::getline(ifs, line)) return nullptr;
        trim(line);
        Customer* cust = nullptr;
        {
            std::istringstream cs(line);
            std::string type, cName, nStr, costStr;
            std::getline(cs, type,    ',');
            std::getline(cs, cName,   ',');
            std::getline(cs, nStr,    ',');
            std::getline(cs, costStr, ',');
            trim(type); trim(cName); trim(nStr); trim(costStr);

            if (type == "Member") {
                std::string tier, extraStr;
                std::getline(cs, tier,     ',');
                std::getline(cs, extraStr, ',');
                trim(tier); trim(extraStr);
                cust = new MemberCustomer(cName, std::stoi(nStr),
                           std::stod(costStr), tier, std::stoi(extraStr));
            } else {
                std::string extraStr;
                std::getline(cs, extraStr, ',');
                trim(extraStr);
                cust = new GuestCustomer(cName, std::stoi(nStr),
                           std::stod(costStr), std::stoi(extraStr));
            }
        }

        Booking* b = new Booking(bName, hName, inDate, outDate, cust, maxR);

        // Skip "ROOMS" header
        std::getline(ifs, line);

        while (std::getline(ifs, line)) {
            trim(line);
            if (line == "END") break;
            if (line.empty()) continue;

            std::istringstream rs(line);
            std::string rType, rId, rName, rTheme, rIn, rOut, durStr;
            std::getline(rs, rType,  ',');
            std::getline(rs, rId,    ',');
            std::getline(rs, rName,  ',');
            std::getline(rs, rTheme, ',');
            std::getline(rs, rIn,    ',');
            std::getline(rs, rOut,   ',');
            std::getline(rs, durStr, ',');
            trim(rType); trim(rId); trim(rName); trim(rTheme);
            trim(rIn);   trim(rOut); trim(durStr);

            if (rType == "Standard") {
                std::string bed;
                std::getline(rs, bed, ',');
                trim(bed);
                try { b->addItem(new StandardRoom(rId, rName, rTheme, rIn, rOut, std::stoi(durStr), bed)); }
                catch (const std::exception& e) { std::cerr << "  [Load error] " << e.what() << "\n"; }
            } else if (rType == "Suite") {
                std::string floorStr;
                std::getline(rs, floorStr, ',');
                trim(floorStr);
                try { b->addItem(new SuiteRoom(rId, rName, rTheme, rIn, rOut, std::stoi(durStr), std::stoi(floorStr))); }
                catch (const std::exception& e) { std::cerr << "  [Load error] " << e.what() << "\n"; }
            }
        }
        return b;
    }

    void saveToFile(const std::string& filename = "data/bookings.txt") const {
        std::filesystem::create_directories(
            std::filesystem::path(filename).parent_path());
        std::ofstream ofs(filename);
        if (!ofs.is_open()) throw FileException(filename);
        ofs << 1 << "\n";
        saveToStream(ofs);
        std::cout << "  [OK] Booking saved to '" << filename << "'.\n";
    }

    void loadFromFile(const std::string& filename = "data/bookings.txt") {
        std::ifstream ifs(filename);
        if (!ifs.is_open()) {
            std::cout << "  [Info] No saved data at '" << filename << "'. Starting fresh.\n";
            return;
        }
        std::string line;
        std::getline(ifs, line); // skip count line
        Booking* loaded = loadFromStream(ifs);
        if (!loaded) return;

        for (auto r : rooms) delete r;
        rooms.clear();
        delete customer;

        bookingName  = loaded->bookingName;
        hotelName    = loaded->hotelName;
        maxRooms     = loaded->maxRooms;
        checkInDate  = loaded->checkInDate;
        checkOutDate = loaded->checkOutDate;
        customer     = loaded->customer;
        rooms        = loaded->rooms;

        loaded->customer = nullptr;
        loaded->rooms.clear();
        delete loaded;

        std::cout << "  [OK] Booking loaded from '" << filename << "'.\n";
    }
};
