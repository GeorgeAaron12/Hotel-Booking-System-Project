#pragma once
#include "Room.h"
#include "Customer.h"
#include "StandardRoom.h"
#include "SuiteRoom.h"
#include "MemberCustomer.h"
#include "GuestCustomer.h"
#include "BookingExceptions.h"
#include <vector>
#include <algorithm>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <filesystem>

using namespace std;

// ---------------------------------------------------------------
// Booking is the main class that ties everything together.
// It represents a single hotel booking — it knows who the guest
// is, which hotel they're at, their check-in/out dates, and
// holds a list of the rooms they've reserved.
//
// Key things this class does:
//   addItem()            - adds a room, checking for duplicates and capacity
//   removeItem()         - removes a room by name
//   findItem()           - searches for a room by name
//   sortItems()          - sorts rooms A-Z by name
//   sortItemsByDuration()- sorts rooms by how many nights booked
//   saveToStream()       - writes all booking data to a file
//   loadFromStream()     - reads booking data back from a file
// ---------------------------------------------------------------

class Booking {
private:
    string bookingName;  // the guest's name — also used as the booking identifier
    string hotelName;    // the name of the hotel
    int maxRooms;        // maximum number of rooms allowed (default is 10, can't be changed later)
    string checkInDate;
    string checkOutDate;
    vector<Room*> rooms; // the list of rooms currently in this booking
    Customer* customer;  // the guest associated with this booking

    // Converts a date from DD-MM-YYYY to YYYY-MM-DD so we can sort dates as strings
    static string toSortable(const string& date) {
        if (date.size() < 10) return date;
        return date.substr(6, 4) + "-" + date.substr(3, 2) + "-" + date.substr(0, 2);
    }

    // Removes the invisible \r character that Windows sometimes adds to the end of lines
    static void trimCR(string& s) {
        if (!s.empty() && s.back() == '\r') s.pop_back();
    }

    // Works out the nightly rate based on room type and time of year.
    // May to August is peak season so prices are higher.
    //   Suite:    EUR 400 (peak)  / EUR 250 (off-peak)
    //   Standard: EUR 300 (peak)  / EUR 150 (off-peak)
    static double getNightlyRate(const string& roomType, const string& checkIn) {
        int month = 0;
        if (checkIn.size() >= 5) {
            try { month = stoi(checkIn.substr(3, 2)); }
            catch (...) {}
        }
        bool peak = (month >= 5 && month <= 8);
        if (roomType == "Suite")
            return peak ? 400.0 : 250.0;
        return peak ? 300.0 : 150.0;
    }

public:
    // Creates a new booking. Max rooms defaults to 10 if you don't specify one.
    Booking(const string& name, const string& hotel,
            const string& in, const string& out,
            Customer* c, int max = 10)
        : bookingName(name), hotelName(hotel), maxRooms(max),
          checkInDate(in), checkOutDate(out), customer(c) {}

    // Cleans up all the rooms and the customer when a booking is destroyed
    ~Booking() {
        for (auto r : rooms) delete r;
        delete customer;
    }

    string getName()        const { return bookingName; }
    string getHotelName()   const { return hotelName; }
    int getMaxRooms()       const { return maxRooms; }
    int getRoomCount()      const { return static_cast<int>(rooms.size()); }
    string getCheckIn()     const { return checkInDate; }
    string getCheckOut()    const { return checkOutDate; }
    string getSortableCheckIn() const { return toSortable(checkInDate); }
    Customer* getCustomer() const { return customer; }

    void setCustomer(Customer* c) {
        delete customer;
        customer = c;
    }

    void setDates(const string& in, const string& out) {
        checkInDate  = in;
        checkOutDate = out;
    }

    // ---------------------------------------------------------------
    // addItem() — adds a room to this booking.
    //
    // Before adding, it runs two checks:
    //
    //   Check 1: Is the booking already full?
    //     If rooms.size() has hit maxRooms, we throw BookingFullException.
    //     This is Branch 1 in our white box test (tested in Test 2).
    //
    //   Check 2: Is this room already in the booking?
    //     We use find_if (an STL algorithm) to scan the rooms list.
    //     find_if goes through each room and uses operator== to compare
    //     names. If it finds a match, we throw DuplicateRoomException.
    //     This is Branch 2 in our white box test (tested in Test 3).
    //
    //   If neither check fires, the room is added. That's the happy
    //   path, which is tested in Test 1.
    // ---------------------------------------------------------------
    void addItem(Room* r) {
        // Check 1: booking is full — throw our custom exception
        if (static_cast<int>(rooms.size()) >= maxRooms)
            throw BookingFullException(maxRooms);

        // Check 2: use find_if to search for a room with the same name
        auto it = find_if(rooms.begin(), rooms.end(),
            [&r](const Room* existing) { return *existing == *r; });

        // If find_if found something, this room is already in the booking
        if (it != rooms.end())
            throw DuplicateRoomException(r->getName());

        rooms.push_back(r);
        cout << "  [OK] Room '" << r->getName() << "' added to booking.\n";
    }

    // ---------------------------------------------------------------
    // removeItem() — removes a room from the booking by name.
    //
    // find_if searches for the room with the matching name. If it
    // can't find one, we throw RoomNotFoundException so the caller
    // knows the removal failed rather than silently doing nothing.
    // ---------------------------------------------------------------
    void removeItem(const string& roomName) {
        // Use find_if to locate the room we want to remove
        auto it = find_if(rooms.begin(), rooms.end(),
            [&roomName](const Room* r) { return r->getName() == roomName; });

        // Room wasn't found — throw our custom exception
        if (it == rooms.end())
            throw RoomNotFoundException(roomName);

        delete *it;
        rooms.erase(it);
        cout << "  [OK] Room '" << roomName << "' removed.\n";
    }

    // ---------------------------------------------------------------
    // findItem() — searches for a room by name and returns a pointer
    // to it, or nullptr if nothing was found.
    //
    // Like addItem and removeItem, this uses find_if with a lambda
    // that compares room names. Tested in White Box Test 4.
    // ---------------------------------------------------------------
    Room* findItem(const string& roomName) const {
        auto it = find_if(rooms.begin(), rooms.end(),
            [&roomName](const Room* r) { return r->getName() == roomName; });
        return (it != rooms.end()) ? *it : nullptr;
    }

    // ---------------------------------------------------------------
    // sortItems() — sorts the rooms list alphabetically A-Z by name.
    //
    // std::sort is given a lambda that tells it how to compare two
    // rooms — it compares their names as strings. The sort criterion
    // (alphabetical order) is built right into that lambda.
    // Tested in White Box Test 4.
    // ---------------------------------------------------------------
    void sortItems() {
        sort(rooms.begin(), rooms.end(),
            [](const Room* a, const Room* b) { return a->getName() < b->getName(); });
        cout << "  [OK] Rooms sorted alphabetically by name.\n";
    }

    // ---------------------------------------------------------------
    // sortItemsByDuration() — sorts rooms from shortest stay to longest.
    //
    // This is the second sort criterion. The lambda compares duration
    // in nights instead of name. Tested in White Box Test 4.
    // ---------------------------------------------------------------
    void sortItemsByDuration() {
        sort(rooms.begin(), rooms.end(),
            [](const Room* a, const Room* b) { return a->getDuration() < b->getDuration(); });
        cout << "  [OK] Rooms sorted by duration (shortest first).\n";
    }

    // Prints a full summary of the booking including each room, its
    // nightly rate, and the final total with any member discount applied
    void displayDetails() const {
        cout << "\n========================================\n"
             << "  BOOKING SUMMARY\n"
             << "========================================\n"
             << "  Hotel:       " << hotelName    << "\n"
             << "  Customer:    " << bookingName  << "\n"
             << "  Rooms:       " << rooms.size() << "/" << maxRooms << "\n"
             << "----------------------------------------\n";

        if (rooms.empty()) {
            cout << "  No rooms added yet.\n";
        } else {
            double baseTotal = 0.0;
            int roomNum = 1;
            for (const auto& r : rooms) {
                double rate      = getNightlyRate(r->getType(), r->getCheckIn());
                double roomTotal = r->getDuration() * rate;
                baseTotal += roomTotal;
                cout << "  Room " << roomNum++ << ":\n"
                     << "    ID:           " << r->getId()             << "\n"
                     << "    Number:       " << r->getName()           << "\n"
                     << "    Type:         " << r->getType()           << "\n"
                     << "    Special Req:  " << r->getSpecialRequests()<< "\n"
                     << "    Check In:     " << r->getCheckIn()        << "\n"
                     << "    Check Out:    " << r->getCheckOut()       << "\n"
                     << "    Duration:     " << r->getDuration()       << " night(s)\n"
                     << "    Rate/Night:   EUR " << rate               << "\n"
                     << "    Room Total:   EUR " << roomTotal          << "\n"
                     << "  ..............................\n";
            }

            // Apply the member discount (0% for guests, up to 20% for platinum members)
            double discount   = customer->getDiscount();
            double finalTotal = baseTotal * (1.0 - discount);

            cout << "  Subtotal:      EUR " << baseTotal << "\n";
            if (discount > 0.0) {
                cout << "  Discount:      " << discount * 100 << "% ("
                     << customer->getType() << ")\n"
                     << "  Total:         EUR " << finalTotal << "\n";
            } else {
                cout << "  Total:         EUR " << finalTotal << "\n";
            }
        }
        cout << "========================================\n";
    }

    // ---------------------------------------------------------------
    // saveToStream() — writes this entire booking to an open file.
    //
    // This is how we save data so it survives after the program closes.
    // Everything is written line by line in a simple text format:
    //
    //   Line 1:  booking name
    //   Line 2:  hotel name
    //   Line 3:  max rooms
    //   Line 4:  check-in date
    //   Line 5:  check-out date
    //   Line 6:  customer details (comma-separated)
    //   Line 7:  "ROOMS"
    //   Lines 8+: one line per room (comma-separated)
    //   Last:    "END"
    //
    // loadFromStream() below knows exactly how to read this back.
    // ---------------------------------------------------------------
    void saveToStream(ofstream& ofs) const {
        ofs << bookingName  << "\n"
            << hotelName    << "\n"
            << maxRooms     << "\n"
            << checkInDate  << "\n"
            << checkOutDate << "\n";

        // Each customer type (Member/Guest) writes itself in its own format
        customer->writeToFile(ofs);

        // Each room type (Standard/Suite) writes itself in its own format
        ofs << "ROOMS\n";
        for (const auto& r : rooms) r->writeToFile(ofs);
        ofs << "END\n";
    }

    // ---------------------------------------------------------------
    // loadFromStream() — reads one booking back from an open file.
    //
    // This is a static factory method — it reads the data saved by
    // saveToStream() and rebuilds the full Booking object from it,
    // including the correct customer type and correct room types.
    //
    // Returns a pointer to the new Booking, or nullptr if reading
    // fails (e.g. the file is empty or corrupt).
    //
    // The try/catch around each addItem() call means a single bad
    // room line won't crash the whole load — it just skips that room
    // and prints a warning.
    // ---------------------------------------------------------------
    static Booking* loadFromStream(ifstream& ifs) {
        // Helper to strip the invisible \r Windows sometimes adds
        auto trim = [](string& s) {
            if (!s.empty() && s.back() == '\r') s.pop_back();
        };

        // Read the five header lines
        string line;
        if (!getline(ifs, line)) return nullptr;
        trim(line);
        string bName = line;

        if (!getline(ifs, line)) return nullptr;
        trim(line);
        string hName = line;

        if (!getline(ifs, line)) return nullptr;
        trim(line);
        int maxR = stoi(line);

        if (!getline(ifs, line)) return nullptr;
        trim(line);
        string inDate = line;

        if (!getline(ifs, line)) return nullptr;
        trim(line);
        string outDate = line;

        // Read the customer line and split it by commas to rebuild the object
        if (!getline(ifs, line)) return nullptr;
        trim(line);
        Customer* cust = nullptr;
        {
            istringstream cs(line);
            string type, cName, nStr, costStr;
            getline(cs, type,    ',');
            getline(cs, cName,   ',');
            getline(cs, nStr,    ',');
            getline(cs, costStr, ',');
            trim(type); trim(cName); trim(nStr); trim(costStr);

            if (type == "Member") {
                string tier, extraStr;
                getline(cs, tier,     ',');
                getline(cs, extraStr, ',');
                trim(tier); trim(extraStr);
                cust = new MemberCustomer(cName, stoi(nStr),
                           stod(costStr), tier, stoi(extraStr));
            } else {
                string extraStr;
                getline(cs, extraStr, ',');
                trim(extraStr);
                cust = new GuestCustomer(cName, stoi(nStr),
                           stod(costStr), stoi(extraStr));
            }
        }

        Booking* b = new Booking(bName, hName, inDate, outDate, cust, maxR);

        getline(ifs, line); // skip the "ROOMS" header line

        // Read each room line until we hit "END"
        while (getline(ifs, line)) {
            trim(line);
            if (line == "END") break;
            if (line.empty()) continue;

            istringstream rs(line);
            string rType, rId, rName, rTheme, rIn, rOut, durStr;
            getline(rs, rType,  ',');
            getline(rs, rId,    ',');
            getline(rs, rName,  ',');
            getline(rs, rTheme, ',');
            getline(rs, rIn,    ',');
            getline(rs, rOut,   ',');
            getline(rs, durStr, ',');
            trim(rType); trim(rId); trim(rName); trim(rTheme);
            trim(rIn);   trim(rOut); trim(durStr);

            if (rType == "Standard") {
                string bed;
                getline(rs, bed, ',');
                trim(bed);
                // If this room line is somehow broken, skip it and carry on
                try { b->addItem(new StandardRoom(rId, rName, rTheme, rIn, rOut, stoi(durStr), bed)); }
                catch (const exception& e) { cerr << "  [Load error] " << e.what() << "\n"; }
            } else if (rType == "Suite") {
                string floorStr;
                getline(rs, floorStr, ',');
                trim(floorStr);
                // If this room line is somehow broken, skip it and carry on
                try { b->addItem(new SuiteRoom(rId, rName, rTheme, rIn, rOut, stoi(durStr), stoi(floorStr))); }
                catch (const exception& e) { cerr << "  [Load error] " << e.what() << "\n"; }
            }
        }
        return b;
    }

    // Saves a single booking to its own file (used in the file I/O white box test)
    void saveToFile(const string& filename = "data/bookings.txt") const {
        filesystem::create_directories(
            filesystem::path(filename).parent_path());
        ofstream ofs(filename);
        if (!ofs.is_open()) throw FileException(filename); // can't open file = our custom error
        ofs << 1 << "\n"; // only one booking in this file
        saveToStream(ofs);
        cout << "  [OK] Booking saved to '" << filename << "'.\n";
    }

    // Loads data from file into this booking, replacing whatever was in it before.
    // Used in White Box Test 5 to verify that a saved booking can be reloaded correctly.
    void loadFromFile(const string& filename = "data/bookings.txt") {
        ifstream ifs(filename);
        if (!ifs.is_open()) {
            cout << "  [Info] No saved data at '" << filename << "'. Starting fresh.\n";
            return;
        }
        string line;
        getline(ifs, line); // skip the booking count at the top
        Booking* loaded = loadFromStream(ifs);
        if (!loaded) return;

        // Swap out the old data for the newly loaded data
        for (auto r : rooms) delete r;
        rooms.clear();
        delete customer;

        bookingName  = loaded->bookingName;
        hotelName    = loaded->hotelName;
        maxRooms     = loaded->maxRooms;
        checkInDate  = loaded->checkInDate;
        checkOutDate = loaded->checkOutDate;
        customer     = loaded->customer;
        rooms        = loaded->rooms;

        // Detach the pointers from loaded so its destructor doesn't free what we just took
        loaded->customer = nullptr;
        loaded->rooms.clear();
        delete loaded;

        cout << "  [OK] Booking loaded from '" << filename << "'.\n";
    }
};
